package common;

import java.util.Date;

public class MemberDTO {
    private int num;
    private String id;
    private String title;
    private String content;
    private int visitcount;

    private Date postdate;

    public MemberDTO() {

    }

    public MemberDTO(int num, String id, String title, String content, Date postdate, int visitcount) {
        this.num = num;
        this.id = id;
        this.title = title;
        this.content = content;
        this.postdate = postdate;
        this.visitcount = visitcount;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getVisitcount() {
        return visitcount;
    }

    public void setVisitcount(int visitcount) {
        this.visitcount = visitcount;
    }


    public Date getPostdate() {
        return postdate;
    }

    public void setPostdate(Date postdate) {
        this.postdate = postdate;
    }
}
