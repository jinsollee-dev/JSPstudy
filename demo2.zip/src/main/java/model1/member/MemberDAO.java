package model1.member;

import common.JDBCConnect;



public class MemberDAO extends JDBCConnect{
    public MemberDAO() {
        super();
    }

    public MemberDTO getMemberDTO(String uid, String upass) {
        MemberDTO dto = new MemberDTO();
        String query = "select * from member where id=? and pass=?";
        try {
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, uid);
            pstmt.setString(2, upass);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                dto.setId(rs.getString("id"));
                dto.setPass(rs.getString("pass"));
                dto.setName(rs.getString("name"));
                dto.setRegidate(rs.getDate("regidate"));

            }
        } catch (Exception ex) {

        }
        return dto;

    }



    public int insertMember(MemberDTO dto){
        int iResult =-1;

        String sql = "insert into tbl_member (user_name, user_id, user_pass) values (?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getId());
            pstmt.setString(3, dto.getPass());
            iResult = pstmt.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return iResult;
    }



}
